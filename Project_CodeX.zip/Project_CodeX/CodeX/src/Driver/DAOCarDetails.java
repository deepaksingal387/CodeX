package Driver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DAOCarDetails 
{

	static Connection con;
	static PreparedStatement ps;
	static Statement st;
	static ResultSet rs;
	
	static {
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/codex","admin","SaiPM221198");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static boolean addCarDetails(String camera_ip,String camera_location,String associated_cameras)
	{
		try
		{
			ps= con.prepareStatement("insert into camera_table(camera_ip,camera_location,associated_cameras)values(?,?,?)");
			
			ps.setString(1, camera_ip);
			ps.setString(2, camera_location);
			ps.setString(3, associated_cameras);
			
			
		
			
			return ps.executeUpdate()>0;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
		
	}
	public ResultSet listCarDetails()
	{
		try
		{
		return con.createStatement().executeQuery("select * from camera_table");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
		
	}

}
