package Driver;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/detailscar.do")
public class DetailsCar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	 doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatch;
		
		String camera_ip,camera_location,associated_cameras;

		camera_ip = request.getParameter("camera_ip");
		camera_location = request.getParameter("camera_location");
		associated_cameras =request.getParameter("associated_cameras");
        

		if (DAOCarDetails.addCarDetails(camera_ip,camera_location,associated_cameras))
		{
			/*out.println("record added.<br><br><br>");*/
			dispatch = request.getRequestDispatcher("TableCarDetails.jsp");
			dispatch.include(request, response);
		}
		else
		{
			out.print("try again...");
			dispatch = request.getRequestDispatcher("DetailsCar.jsp");
			dispatch.include(request, response);
		}

		
	}

}
